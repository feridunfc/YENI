# COLUMN-GOLDEN-02 — ideCAD rapor analizi

Yalnız rapor verileri ve bağımsız aritmetik; Column Engine çalıştırılmadı, yönetmelik genel kabulü verilmedi. Kaynak `1.pdf` ve `2.pdf` SHA-256 kayıtları JSON içinde; eski model değişmedi. PDF fiziksel sayfa numaraları kullanıldı.

- `1.pdf`: 3 m/40×40/A15; zemin `α=1.00`, `φ=0.0102`, β=1.00. A15/perdesiz modelde sistem seçimi hatası vardı.
- `2.pdf`: 5 m/30×30/A11; zemin `α=34.8720/55.6859=0.62623` (PDF s. 189), `φ=0.0939` (PDF s.185); 1. kat φ=0.0543. Böylece hem TS 500 yanal ötelenmesi önlenmemiş dalı hem TBDY α<0.7 negatif dalı canlı raporda etkin.
- Bireysel TS500 β `1/(1-1.3 Nd/Nk)` ve kat βs `1/(1-1.3 ΣNd/ΣNk)` sayıları raporla uyumlu (PDF s.186).
- Raporun **Alındı β** değerleri β×βs ile eşleşiyor. Fakat test edilen 30×30 örneklerde TS500 denk.7.29 (`lk/i > 35/sqrt(Nd/(fck Ac))`) koşulu **sağlanmıyor**. Çarpımın fiilen hesapta kullanılıp kullanılmadığı / nedeni IDECAD denetim konusu olarak açık; otomatik yazılım hatası hükmü verilmedi.
- `2.pdf` s.27 TBDY global θ zemin 0.0578 ve ilgili β 1.0. TS500 yerel büyütme ile farklı yöntemdir.
- `2.pdf` s.182 ve 186 tasarım ve uç moment sayıları aynı görünüyor: büyütmenin PMM'ye nasıl aktarıldığı doğrudan raporda net değildir.
- Hem kesit hem kat yüksekliği ve sistem katsayıları değiştiği için önce-sonra testi **tek değişkenli nedensellik testi değildir**.

`python -m unittest discover -s . -p 'test_golden02_arithmetic.py' -v` ile yedi aritmetik test çalıştırılır. **Bu testlerin başarısı mühendislik kabulü değildir.**
