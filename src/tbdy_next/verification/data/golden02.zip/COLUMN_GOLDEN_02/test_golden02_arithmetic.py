"""Arithmetic only: source-replay checks, not code or structural acceptance."""
import unittest, json, math
from pathlib import Path
D=json.loads((Path(__file__).parent/'audit_fixture.json').read_text(encoding='utf-8'))
class Golden02(unittest.TestCase):
    def test_alpha_ground_fails(self):
        a=D['revised']['alpha']['ground']
        self.assertAlmostEqual(a['Vis']/a['Vik'],a['reported'],delta=.00005)
        self.assertLess(a['reported'],.7)
    def test_alpha_top(self):
        a=D['revised']['alpha']['top']
        self.assertAlmostEqual(a['Vis']/a['Vik'],1.)
    def test_sway_branch_changed(self):
        self.assertLess(D['reference']['ground_phi'],.05)
        self.assertGreater(D['revised']['phi']['ground'],.05)
    def test_beta_member_ts500_denominator(self):
        for r in D['revised']['member_cases']:
            actual=1/(1-1.3*r['Nd']/r['Nk'])
            self.assertAlmostEqual(actual,r['beta'],delta=.0052)
    def test_beta_story(self):
        for v in D['revised']['sum_N'].values():
            self.assertAlmostEqual(1/(1-1.3*v['Nd']/v['Nk']),v['beta_s'],delta=.005)
    def test_report_used_is_product_arithmetically(self):
        for r in D['revised']['member_cases']:
            v=D['revised']['sum_N'][r['story']]
            prod=1/(1-1.3*r['Nd']/r['Nk'])/(1-1.3*v['Nd']/v['Nk'])
            self.assertAlmostEqual(prod,r['reported_used'],delta=.012)
    def test_ts500_729_requires_separate_branch_proof(self):
        # All four printed probes lie BELOW TS500 7.29 product threshold.
        b=.30; A=b*b; i=b/math.sqrt(12); fck=30000.
        for r in D['revised']['member_cases']:
            slender=r['lk']/i
            boundary=35/math.sqrt(r['Nd']/(fck*A))
            self.assertLess(slender,boundary)
if __name__=='__main__': unittest.main()
