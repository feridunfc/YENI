#!/usr/bin/env python3
"""Independent, limited arithmetic comparisons extracted from an ideCAD report.
This intentionally does NOT certify code compliance, PMM, SCWB applicability or project validity.
"""
import json, math, unittest
from pathlib import Path
DATA=json.loads((Path(__file__).parent/'fixtures.json').read_text(encoding='utf-8'))

def calculate(c):
    x=c['inputs']; k=c['id']
    if k == 'SDS': return x['Ss']*x['Fs']
    if k == 'SD1': return x['S1']*x['F1']
    if k == 'TA': return .2*x['SD1']/x['SDS']
    if k == 'TB': return x['SD1']/x['SDS']
    if k == 'PROVIDED_AS': return x['bar_count']*math.pi*(x['diameter_mm']**2)/4/100
    if k == 'CONFINEMENT_ASW_OVER_S': return x['legs']*math.pi*x['tie_diameter_mm']**2/4/100/(x['s_mm']/1000)
    if k == 'AC': return x['b_cm']*x['h_cm']
    if k == 'CONFINEMENT_AXIAL_BRANCH_THRESHOLD': return .2*x['Ac_cm2']*.1*x['fck_MPa']
    if k == 'AXIAL_TBDY_LIMIT': return .4*x['Ac_cm2']*.1*x['fck_MPa']
    if k == 'AXIAL_TS500_LIMIT': return .9*x['Ac_cm2']*.1*x['fcd_MPa']
    if k == 'JOINT_UNCONFINED_LIMIT': return x['bj_mm']*x['h_mm']*math.sqrt(x['fck_MPa'])/1000
    if k == 'JOINT_CONFINED_LIMIT': return 1.7*x['bj_mm']*x['h_mm']*math.sqrt(x['fck_MPa'])/1000
    if k == 'SCWB_COLUMN_SUM': return x['Mr_lower']+x['Mr_upper']
    if k == 'SCWB_BEAM_1P2_SUM': return 1.2*(x['Mr_beam_left']+x['Mr_beam_right'])
    if k == 'SCWB_NUMERIC_INEQUALITY': return (x['Mr_lower']+x['Mr_upper']) > 1.2*(x['Mr_beam_left']+x['Mr_beam_right'])
    if k == 'JOINT_VE_ONE_BEAM_APPROX': return 1.25*x['fyk_MPa']*x['As1_cm2']*100/1000-x['Vcol_kN']
    if k == 'JOINT_VE_TWO_BEAM_APPROX': return 1.25*x['fyk_MPa']*(x['As1_cm2']+x['As2_cm2'])*100/1000-x['Vcol_kN']
    if k in ('THETA_GROUND','THETA_UPPER'): return x['sum_W_above_kN']*(x['delta_avg_mm']/1000)/(x['story_shear_kN']*x['height_m'])
    if k in ('SWAY_PHI_GROUND','SWAY_PHI_UPPER'): return 1.5*(x['delta_mm']/1000)*x['sum_N_over_L_kN_per_m']/x['story_shear_kN']
    if k == 'DRIFT_LAMBDA': return x['Sae_DD3']/x['Sae_DD2']
    if k == 'LOCAL_BETA_NON_DIAGNOSTIC': return max(1.,x['Cm']/(1-1.3*x['Nd_kN']/x['Nk_kN']))
    raise ValueError(k)

class ReportArithmetics(unittest.TestCase):
    def test_cases(self):
        for c in DATA['arithmetic_cases']:
            with self.subTest(c['id']):
                actual=calculate(c)
                if c['kind']=='BOOLEAN': self.assertIs(actual, c['expected'])
                else: self.assertLessEqual(abs(actual-c['expected']), c['absolute_tolerance'], (c['id'],actual,c['expected']))
    def test_invalid_system_is_never_accepted(self):
        self.assertEqual(DATA['acceptance_policy']['global_compliance'],'BLOCKED_A15_SYSTEM_MISMATCH')
        self.assertEqual(len(DATA['model']['from_pdf']['warnings']),2)
    def test_regression_not_misrepresented(self):
        self.assertEqual(DATA['acceptance_policy']['design_PM_M'],'NOT_PROVEN')
        self.assertEqual(DATA['acceptance_policy']['numerical_solver_comparison'],'NOT_PERFORMED')
if __name__=='__main__': unittest.main(verbosity=2)
