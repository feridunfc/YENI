# COLUMN-GOLDEN-01 — ideCAD PDF'inden bağımsız karşılaştırma paketi

**Kaynak:** `1.pdf` (197 sayfa), SHA-256 `189ca7a47fb89b1fb2f720cd4c8a4e0ce3b61f14abe9a698d9fd2b7756aba30c`. PDF sayfa numaraları dosyanın 1-bazlı numaralarıdır; basılı ideCAD sayfaları genel olarak dosya sayfası eksi 2'dir. Header/footer göz ardı edilmiştir. Kullanıcı beyanı: **duvar yükü yok, Q=2 kN/m², döşeme 15 cm**.

## Bilinen uygulanabilirlik hatası

PDF sayfa 4, X ve Y'de **A15** sisteminde perde bulunmadığını hata olarak bildiriyor. Bu durumda bina geneli `PASS` yasaktır. Mevcut rapor, matematiksel ara sonuçları için yararlı bir **negative qualification golden** olmalıdır; geçerli yönetmelik projesi için pozitif golden değildir. Çözüm: ayrı kopyada perde içermeyen çerçeve için şartnameye uygun sistem seçimini doğrulayıp analizi güncellemek; iki raporu karıştırmamak.

## Girdi disiplini

- Geometri: 2 kat × 3 m, kat başına 9 adet 40×40 cm kolon; 30×50 cm kiriş; 15 cm döşeme.
- Deprem kaynağı: ZA, DD-2, Ss=0.824, S1=0.239, Fs=F1=0.8, R=7, D=2.5, I=1. Bunlar **raporda kullanılmış değerlerdir, geçerli sistem onayı değildir**.
- PDF kat planındaki döşeme G=5.148 kN/m². Özağırlık 0.15×24.516625=3.677494 kN/m². G farkı 1.470506 kN/m²; duvar yükü olmadığından bitiş/ilave G tanımı modelde doğrulanmalıdır.
- PDF kolon donatı sayfasında `Ast=16.00 cm²` ile kapasite sayfasındaki sağlanan `8Ø14+4Ø14=18.47 cm²` karıştırılmamalıdır.

## Çalıştırılabilir aritmetik testler

`python test_golden.py`

**23 ayrı sayısal/boole karşılaştırma örneği**, + uygunsuz sistem kuralı için negatif test ve kayıt kapsamını denetleyen test. Testler rapor sayılarının bağımsız yeniden üretimidir; Column motorunun çalıştırılması veya TS500/TBDY tasarım kabulü değildir.

### Özellikle önemli yeniden hesaplamalar

| Kaynak (PDF sayfa) | Hesap | Bağımsız sonuç | Rapor | Yorum |
|---|---|---:|---:|---|
| 183/196 | 12Ø14 boyuna donatı | 18.4726 cm² | 18.47 | `Ast=16` ayrı değişken |
| 184 | 4 kol Ø8, s=80 mm | 25.1327 cm²/m | 25.13 | Kol geometrisi bağımsız doğrulanmalı |
| 194 | Kuşatılmamış birleşim sınırı | 876.356 kN | 876.36 | Sadece dayanım dalı |
| 194 | Kuşatılmış birleşim sınırı | 1489.805 kN | 1489.81 | Kuşatılma sınıfı ayrıca doğrulanmalı |
| 191 | Merkezi alt+üst kolon momenti | 347.34 kNm | 347.34 | Nd kapasite seçimi açık |
| 191 | Kiriş momentleri ×1.2 | 185.8788 kNm | 185.88 | SCWB eşitsizliği sağlanıyor |
| 28 | Zemin kat θ | 0.00751685 | 0.0075 | Yuvarlama içinde |
| 186 | Zemin kat stabilite φ | 0.0102143 | 0.0102 | Yuvarlama içinde |
| 187 | Örnek yerel β | 1.0000 | 1.00 | **Hatalı β formülünü ortaya çıkarmaz** |

## Recipe açıklığı → kapatma kanıtı

| Recipe alanı | Bu PDF ile kapanan kısım | Açık kalan ve gereken test |
|---|---|---|
| Yük ve malzeme | C30/B420C, G, Q, kombinasyon metni, fcd ve fyd raporlandığı şekilde | G ek kalemleri, duvar alanı, gerçek model kaynakları |
| PMM | N-M2-M3 tablo talebi, Ast/sağlanan As ayrımı, bazı ayrı kapasite sayıları | Eşzamanlı talep, gerçek çubuk koordinatları, 3B yüzey ve bağımsız etkileşim oracle'ı |
| Narinlik | φ, lk, Nk, Nd, Cm, β kayıtları ve φ aritmetiği | **β>1** olan seçilmiş örnek; `1-1.3 Nd/Nk` dalı; EI, k, global/local ayrımı |
| Kesme | Ve, Vc, Vr ve kapasite ara değerleri | Vc=0/pozitif dalının uygulanabilirliği, Ma/Mü seçim politikası ve alt/üst sınırlar |
| Sargı | Dört kollu Ø8/s ve Asw/s sayısı | Çiroz bağlantı topolojisi, bölgesel aralık ve ankraj |
| SCWB | Alt+üst ve komşu kiriş momenti toplamları | Uygulama istisnaları, doğru Nd altında kapasite, iki işaret ve topoloji |
| Birleşim | 876.36/1489.81 dayanım ve yaklaşık Ve ters hesabı | Kuşatılmış/kuşatılmamış fiziksel sınıflandırma, As1/As2 kesin değeri |
| Global sistem | θ, λ, φ ve A15 **uygunsuzluk** kanıtı | Uygun sistem seçimi, bütün bina analizi, ETABS eşdeğer çözüm |

## En kısa hedefli sonraki örnekler

1. **GOLDEN-01B (sistem düzeltilmiş kopya):** Geometri, malzeme ve Q aynı; A15 hata veren sistem seçimi şartnameye uygun çerçeve sınıfına getirilir. Tasarım ve analiz tekrar çalışır; doğru R/D/I ayrı kaydedilir. Böylece pozitif bina-kapsam benchmark'ı oluşur.
2. **GOLDEN-02 (narinlik):** Büyütme katsayısı **β>1.10** olacak şekilde daha narin, fakat geçerli kabul dallarına sahip örnek. Nk/Nd/Cm/lk/M1/M2 tümüyle dökülür. Eski ikinci mertebe hatasını bu örnek yakalar.
3. **GOLDEN-03 (SCWB sınır):** Aynı merkezi birleşimde yalnız bir kirişin/kolonun donatısı kontrollü değiştirilir; ilgili kontrol için açıkça **SCWB FAIL** ve birleşim dalı raporlanır. Kaynak hesapla bağımsız doğrulama yapılır.

**Kabul politikası:** İki yazılımın aynı rapor sayısını üretmesi yeterli değil. Şartname uygulanabilirlik + bağımsız sayısal referans + kaynak kanıtı birlikte olmadan `FULL_ENGINEERING_ACCEPTANCE` verilmez.
